/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.registration.business.security.control;

import it.polimi.registration.business.security.control.util.Message;
import it.polimi.registration.business.security.entity.Event;
import it.polimi.registration.business.security.entity.Group;
import it.polimi.registration.business.security.entity.User;
import java.security.Principal;
import java.util.Collection;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author miglie
 */
@Stateless
public class UserManager {

    @PersistenceContext
    EntityManager em;

    @Inject
    Principal principal;

    public Message save(User user) {
        Message status = vertifyUserInput(user);
        if (status.getCode() == Message.STATUS_OK) {
            user.setGroupName(Group.USERS);
            em.persist(user);
        }
        return status;

    }

    public void unregister() {
        em.remove(getLoggedUser());
    }

    public User getLoggedUser() {
        return em.find(User.class, principal.getName());
    }

    public void addCreatedEvent(Event event) {
        getLoggedUser().addCreatedEvent(event);
    }

    private boolean existsUser(User user) {
        return findById(user.getUserId()) != null;
    }

    public User findById(Integer id) {
        return em.find(User.class, id);
    }

    public void changePassword(User user, String password) {
        user.setPassword(password);
        em.merge(user);
    }

    public void changeName(User user, String name) {
        user.setName(name);
        em.merge(user);
    }

    public void inviteUserToEvent(User user, Event event) {
        user.addPendingEvent(event);
    }

    public Collection<Event> getCreatedEvents(User user) {
        return user.getCreatedEvents();
    }

    public Collection<Event> getParticipatingEvents(User user) {
        return user.getParticipatingEvents();
    }

    public Collection<Event> getPendngEvents(User user) {
        return user.getPendingEvents();
    }

    //db queries
    public Collection<User> findAllUsers() {
        return em.createNamedQuery("findAllUsers", User.class).getResultList();
    }

    public User findByEmail(String email) {
        Query byEmail = em.createNamedQuery("findUserByEmail");
        try {
            User user = (User) byEmail.setParameter("email", email).getSingleResult();
            return user;
        } catch (NoResultException e) {
            return null;
        }
    }

    private Message vertifyUserInput(User user) {
        Message status = new Message(Message.STATUS_OK, "Unique entry");
        if (user.getEmail() == null || user.getName() == null) {
            status.setCode(Message.STATUS_ERR);
            status.setMessage("Input fields must not be empty");
        }else if (emailExists(user.getEmail())) {
            status.setCode(Message.DUPLICATE_EMAIL);
            status.setMessage("User with this email is already registered");
        }else if (nameExists(user.getName())) {
            status.setCode(Message.DUPLICATE_NAME);
            status.setMessage("User with this name is already registered");
        }
        return status;
    }

    public boolean emailExists(String email) {
        Query byEmail = em.createQuery(
                "SELECT  COUNT(u) FROM USERS u WHERE u.email='" + email + "'");
        try {
            return (Long) byEmail.getSingleResult() == 1;
        } catch (NoResultException e) {
            return false;
        }

    }

    public boolean nameExists(String name) {
        Query byName = em.createQuery(
                "SELECT  COUNT(u) FROM USERS u WHERE u.name='" + name + "'");
        try {
            return (Long) byName.getSingleResult() == 1;
        } catch (NoResultException e) {
            return false;
        }

    }

}
