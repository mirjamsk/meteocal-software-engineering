/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.registration.business.security.boundary;

import it.polimi.registration.business.security.control.EventManager;
import it.polimi.registration.business.security.entity.Event;
import it.polimi.registration.business.security.entity.Location;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;
import org.primefaces.context.RequestContext;

/**
 *
 * @author Alojzije
 */
@ManagedBean
@ViewScoped
public class EventBean {

    @EJB
    EventManager eventManager;
    @ManagedProperty(value="#{locationBean}")
    private LocationBean locationBean;

   
    private String title;
    private Date startTime;
    private Date endTime;
    private String description = "";
    private Event selectedEvent;


    public EventBean() {}

    public String createEvent() {
         RequestContext context = RequestContext.getCurrentInstance();  

        Location location = locationBean.getLocation();
        Event event = eventManager.createNewEvent(title, description, startTime, endTime);
        eventManager.save(event, location);

        context.addCallbackParam("saved", true);  
        context.addCallbackParam("creationFailed", false);  
        context.addCallbackParam("eventId", event.getEventId()); 
        
        setSelectedEvent(event);
        resetValues();
        locationBean.resetValues();
        
        return null;
       
    }

    public void checkStartDate(FacesContext context, UIComponent validate, Object value) {

        Date startTimeTemp = (Date) value;
        if (this.endTime != null) {
            if (startTimeTemp.after(this.endTime)) {
                System.out.println("Start time cannot be after end time");
                this.startTime = null;
                ((UIInput) validate).setValid(false);
                FacesMessage message = new FacesMessage();
                message.setSeverity(FacesMessage.SEVERITY_ERROR);
                message.setSummary("Start time cannot be after end time");
                message.setDetail("");
                context.addMessage("startDate", message);

                throw new ValidatorException(message);
            }
        }
        if (startTimeTemp.before(Calendar.getInstance().getTime())) {
            System.out.println("That date has passed, choose another start time");
            this.startTime = null;
            ((UIInput) validate).setValid(false);
            FacesMessage message = new FacesMessage();
            message.setSeverity(FacesMessage.SEVERITY_ERROR);
            message.setSummary("That date has passed, choose another start time");
            message.setDetail("");
            context.addMessage("startDate", message);
            throw new ValidatorException(message);
        }
        System.out.println("All good in startTime");
        this.setStartTime(startTimeTemp);

    }

    public void checkEndDate(FacesContext context, UIComponent validate, Object value) {

        Date endTimeTemp = (Date) value;

        if (this.startTime != null) {
            if (endTimeTemp.before(this.startTime)) {
                System.out.println("End time cannot be before start time");
                this.startTime = null;
                ((UIInput) validate).setValid(false);
                FacesMessage message = new FacesMessage();
                message.setSeverity(FacesMessage.SEVERITY_ERROR);
                message.setSummary("End time cannot be before start time");
                message.setDetail("");
                throw new ValidatorException(message);
            }
        }
        if (endTimeTemp.before(Calendar.getInstance().getTime())) {
            System.out.println("That date has passed, choose another end time");
            this.startTime = null;
            ((UIInput) validate).setValid(false);
            FacesMessage message = new FacesMessage();
            message.setSeverity(FacesMessage.SEVERITY_ERROR);
            message.setSummary("That date has passed, choose another end time");
            message.setDetail("");
            throw new ValidatorException(message);
        }
        System.out.println("All good in endTime");

        this.setEndTime(endTimeTemp);

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


 public LocationBean getLocationBean() {
        return locationBean;
    }

    public void setLocationBean(LocationBean locationBean) {
        this.locationBean = locationBean;
    }

    private Collection<Event> getAllEvents;

    public Collection<Event> getGetAllEvents() {
        return eventManager.findAllEvents();
    }

    public void setGetAllEvents(Collection<Event> getAllEvents) {
        this.getAllEvents = getAllEvents;
    }

    private void resetValues() {
        title = null;
        startTime = null;
        endTime = null;
    }
    
    private Event findEventById(int id){
        return eventManager.findById(id);
    }
    
    private void deleteEvent(Event event){
        eventManager.deleteEvent(event);
    }
    
    public Event getSelectedEvent() {
        return selectedEvent;
    }

    public void setSelectedEvent(Event selectedEvent) {
        this.selectedEvent = selectedEvent;
    }
    public void updateEvent(){
        eventManager.updateEvent(selectedEvent);
         RequestContext context = RequestContext.getCurrentInstance();  
        context.addCallbackParam("saved", true);  
        context.addCallbackParam("creationFailed", false);  
    }
    
    

}
