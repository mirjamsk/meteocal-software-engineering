/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.registration.business.security.control;

import it.polimi.registration.business.security.entity.Event;
import it.polimi.registration.business.security.entity.Location;
import it.polimi.registration.business.security.entity.User;
import it.polimi.registration.business.security.entity.Weather;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Alojzije
 */
@Stateless
public class EventManager {
    @PersistenceContext
    EntityManager em;
   

     @EJB
    UserManager um;
     public Event createNewEvent(String title, String description, Date start, Date end){
         Event e = new Event();
         e.setDescription(description);
         e.setTitle(title);
         e.setStartTime(start);
         e.setEndTime(end);
         return e;
     }
     
    public void save(Event event, Location location){
        event.setLocation(location);
        enrichWithWeather(event);
        //test
        User creator = um.getLoggedUser();
        event.setCreator(creator);        
        event.addParticipatingUser(creator);
        em.persist(event);
        event.getLocation().setEvent(event);

        creator.addCreatedEvent(event);
        creator.addParticipatingEvent(event);
               
    }

    
    //izmjena kasnije
    public void enrichWithWeather(Event event){
         Weather w = new Weather();
        w.setIsBadWeather(false);
        w.setUpdatedDate(Calendar.getInstance().getTime());
        em.persist(w);
        event.setWeather(w);
    }
    
    public User getCreator(Event event) {
        return event.getCreator();
    }
    
    public String getLocationAddress(Event event){
        return event.getLocation().getAddress();
    }
    
    public void addParticipants(Event event, Collection<User> users) {
        for (User user : users) {
            event.addParticipatingUser(user);
            user.addParticipatingEvent(event);
        }
    }

    public void addParticipants(Event event, User user) {
        event.addParticipatingUser(user);
        user.addParticipatingEvent(event);
    }


    public void inviteUsersToEvent(Collection<User> users, Event event) {
        for (User user : users) {
            event.addInvitedUser(user);
            user.addPendingEvent(event);
        }
    }

    public void inviteUsersToEvent(User user, Event event) {
        event.addInvitedUser(user);
        user.addPendingEvent(event);

    }

  
        //db queries
    public Collection<Event> findAllEvents() {
        return em.createNamedQuery("findAllEvents", Event.class).getResultList();
    }
    
    public Event findById(int id) {
        return em.find(Event.class, id);
    }
    public void deleteEvent(Event event){
        // remove, location,
        //remove ffrom user paricipation? 
        //all kid of stuff;
        em.remove(findById(event.getEventId()));	
    }

    public void updateEvent(Event event) {
       em.merge(event);
    }
}
