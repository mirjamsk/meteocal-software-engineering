/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.registration.business.security.boundary;

import it.polimi.registration.business.security.control.UserManager;
import it.polimi.registration.business.security.control.util.Message;
import it.polimi.registration.business.security.entity.User;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author miglie
 */
@Named
@RequestScoped
public class RegistrationBean {

    @EJB
    private UserManager um;

    private User user;

    private String pswd;

    private Logger logger;

    public RegistrationBean() {
    }

    public User getUser() {
        if (user == null) {
            user = new User();
        }
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String register() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
        Message status;
        status = um.save(user);
        if (status.getCode() != Message.STATUS_OK) {
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,  status.getMessage(), "Registration Failed"));
        } else {
        //return "user/home?faces-redirect=true";

            try {
                request.login(user.getEmail(), this.pswd);
                return "/user/home";
            } catch (ServletException e) {
                context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Registration login Failed", "Login Failed"));
                logger.log(Level.SEVERE, "Registration Failed");
            }
        }
        return null;

    }

    public String getPswd() {
        return pswd;
    }

    public void setPswd(String pswd) {
        this.pswd = pswd;
    }

}
