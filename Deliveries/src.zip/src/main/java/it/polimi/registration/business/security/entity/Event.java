/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.registration.business.security.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Alojzije
 */
@Entity
@Table(name = "event")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "findAllEvents", query = "SELECT e FROM Event e ORDER BY e.startTime DESC"),
    @NamedQuery(name = "Event.findByEventId", query = "SELECT e FROM Event e WHERE e.eventId = :eventId"),
    @NamedQuery(name = "Event.findByTitle", query = "SELECT e FROM Event e WHERE e.title = :title"),
    @NamedQuery(name = "Event.findByStartTime", query = "SELECT e FROM Event e WHERE e.startTime = :startTime"),
    @NamedQuery(name = "Event.findByEndTime", query = "SELECT e FROM Event e WHERE e.endTime = :endTime")})
public class Event implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "event_id")
    private Integer eventId;
    @Basic(optional = false)
    @Column(name = "title")
    private String title;
    @Size(max = 2000)
    @Column(name = "description")
    private String description;
    @Basic(optional = false)
    @Column(name = "start_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startTime;
    @Basic(optional = false)
    @Column(name = "end_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endTime;

    @JoinColumn(name = "creator_id", referencedColumnName = "user_id")
    @ManyToOne(optional = false, cascade = CascadeType.PERSIST)
    private User creator;

    @ManyToMany
    @JoinTable(name = "user_event_participating",
            joinColumns = @JoinColumn(name = "p_event_id", referencedColumnName = "event_id"),
            inverseJoinColumns = @JoinColumn(name = "p_user_id", referencedColumnName = "user_id"))
    private Collection<User> participatingUsers;

    @JoinTable(name = "user_event_invited", joinColumns = {
        @JoinColumn(name = "i_event_id", referencedColumnName = "event_id")}, inverseJoinColumns = {
        @JoinColumn(name = "i_user_id", referencedColumnName = "user_id")})
    @ManyToMany
    private Collection<User> invitedUsers;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "associatedEvent")
    private Collection<Notification> notifications;

    @JoinColumn(name = "e_weather_id", referencedColumnName = "weather_id")
    @OneToOne(optional = false)
    private Weather weather;
    @JoinColumn(name = "e_location_id", referencedColumnName = "location_id")
    @OneToOne(optional = false)
    private Location location;

    public Event() {
    }

    public Event(Integer eventId) {
        this.eventId = eventId;
    }

    public Event(Integer eventId, String title, boolean isOutdoor, Date startTime, Date endTime) {
        this.eventId = eventId;
        this.title = title;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public Integer getEventId() {
        return eventId;
    }

    public void setEventId(Integer eventId) {
        this.eventId = eventId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    @XmlTransient
    public Collection<User> getParticipatingUsers() {
        if (participatingUsers == null) {
            participatingUsers = new ArrayList<>();
        }
        return participatingUsers;
    }

    public void addParticipatingUser(User user) {
        if (!getParticipatingUsers().contains(user)) {
            getParticipatingUsers().add(user);
        }
    }

    public void setParticipatingUsers(Collection<User> participatingUsers) {
        this.participatingUsers = participatingUsers;
    }

    @XmlTransient
    public Collection<User> getInvitedUsers() {
        if (invitedUsers == null) {
            invitedUsers = new ArrayList<>();
        }
        return invitedUsers;
    }

    public void addInvitedUser(User user) {
        if (!getInvitedUsers().contains(user)) {
            getInvitedUsers().add(user);
        }
    }

    public void setInvitedUsers(Collection<User> invitedUsers) {
        this.invitedUsers = invitedUsers;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public User getCreator() {
        return creator;
    }

    public void setCreator(User creator) {
        this.creator = creator;

    }

    public Weather getWeather() {
        return weather;
    }

    public void setWeather(Weather weather) {
        this.weather = weather;
    }

    @XmlTransient
    public Collection<Notification> getNotificationCollection() {
        if (notifications == null) {
            notifications = new ArrayList<>();
        }
        return notifications;
    }

    public void setNotificationCollection(Collection<Notification> notificationCollection) {
        this.notifications = notificationCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (eventId != null ? eventId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Event)) {
            return false;
        }
        Event other = (Event) object;
        if ((this.eventId == null && other.eventId != null) || (this.eventId != null && !this.eventId.equals(other.eventId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Event[ eventId=" + eventId + " ]";
    }

}
