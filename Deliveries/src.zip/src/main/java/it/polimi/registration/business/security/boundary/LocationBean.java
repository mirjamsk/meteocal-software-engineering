/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.registration.business.security.boundary;

import it.polimi.registration.business.security.control.LocationManager;
import it.polimi.registration.business.security.entity.Location;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/**
 *
 * @author Alojzije
 */
@ManagedBean
@ViewScoped
public class LocationBean {

    @EJB
    LocationManager locationManager;
    private String address;
    private boolean isOutdoor;
    private Location location;

    //creates and saves location
    public void saveLocation() {
        location = locationManager.createNewLocation(address, isOutdoor);
        locationManager.save(location);

    }

    public Location getLocation() {
        if (location == null) {
            saveLocation();
        }
        return location;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public boolean isIsOutdoor() {
        return isOutdoor;
    }

    public void setIsOutdoor(boolean isOutdoor) {
        this.isOutdoor = isOutdoor;
    }

    public void resetValues() {
        address = null;
        isOutdoor = false;
        location = null;
    }

}
