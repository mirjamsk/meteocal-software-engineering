/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.registration.business.security.control;

import it.polimi.registration.business.security.entity.Weather;
import java.util.Calendar;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Alojzije
 */
public class WeatherManager {
     @PersistenceContext
    EntityManager em;
    public Weather createNewWeatherInstance(){
        Weather w = new Weather();
        w.setIsBadWeather(false);
        w.setUpdatedDate(new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()));
        em.persist(w);
        return w;
    }
    
    public void save(Weather w){
        em.persist(w);
    }
}
