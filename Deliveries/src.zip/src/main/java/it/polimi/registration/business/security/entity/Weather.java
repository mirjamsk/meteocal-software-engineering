package it.polimi.registration.business.security.entity;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Alojzije
 */
@Entity
@Table(name = "weather")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Weather.findAll", query = "SELECT w FROM Weather w"),
    @NamedQuery(name = "Weather.findByWeatherId", query = "SELECT w FROM Weather w WHERE w.weatherId = :weatherId"),
    @NamedQuery(name = "Weather.findByUpdatedDate", query = "SELECT w FROM Weather w WHERE w.updatedDate = :updatedDate"),
    @NamedQuery(name = "Weather.findByIsBadWeather", query = "SELECT w FROM Weather w WHERE w.isBadWeather = :isBadWeather"),
    @NamedQuery(name = "Weather.findBySun", query = "SELECT w FROM Weather w WHERE w.sun = :sun"),
    @NamedQuery(name = "Weather.findByRain", query = "SELECT w FROM Weather w WHERE w.rain = :rain"),
    @NamedQuery(name = "Weather.findByThunderstorm", query = "SELECT w FROM Weather w WHERE w.thunderstorm = :thunderstorm"),
    @NamedQuery(name = "Weather.findByClouds", query = "SELECT w FROM Weather w WHERE w.clouds = :clouds"),
    @NamedQuery(name = "Weather.findBySnow", query = "SELECT w FROM Weather w WHERE w.snow = :snow"),
    @NamedQuery(name = "Weather.findByTemperaure", query = "SELECT w FROM Weather w WHERE w.temperaure = :temperaure")})
public class Weather implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "weather_id")
    private Integer weatherId;
    @Basic(optional = false)
    @Column(name = "updated_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;
    @Basic(optional = false)
    @Column(name = "is_bad_weather")
    private boolean isBadWeather;
    @Column(name = "sun")
    private Boolean sun;
    @Column(name = "rain")
    private Boolean rain;
    @Column(name = "thunderstorm")
    private Boolean thunderstorm;
    @Column(name = "clouds")
    private Boolean clouds;
    @Column(name = "snow")
    private Boolean snow;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "temperaure")
    private Float temperaure;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "weather" , orphanRemoval=true)
    private Event event;

    public Weather() {
    }

    public Weather(Integer weatherId) {
        this.weatherId = weatherId;
    }

    public Weather(Integer weatherId, Date updatedDate, boolean isBadWeather) {
        this.weatherId = weatherId;
        this.updatedDate = updatedDate;
        this.isBadWeather = isBadWeather;
    }

    public Integer getWeatherId() {
        return weatherId;
    }

    public void setWeatherId(Integer weatherId) {
        this.weatherId = weatherId;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public boolean getIsBadWeather() {
        return isBadWeather;
    }

    public void setIsBadWeather(boolean isBadWeather) {
        this.isBadWeather = isBadWeather;
    }

    public Boolean getSun() {
        return sun;
    }

    public void setSun(Boolean sun) {
        this.sun = sun;
    }

    public Boolean getRain() {
        return rain;
    }

    public void setRain(Boolean rain) {
        this.rain = rain;
    }

    public Boolean getThunderstorm() {
        return thunderstorm;
    }

    public void setThunderstorm(Boolean thunderstorm) {
        this.thunderstorm = thunderstorm;
    }

    public Boolean getClouds() {
        return clouds;
    }

    public void setClouds(Boolean clouds) {
        this.clouds = clouds;
    }

    public Boolean getSnow() {
        return snow;
    }

    public void setSnow(Boolean snow) {
        this.snow = snow;
    }

    public Float getTemperaure() {
        return temperaure;
    }

    public void setTemperaure(Float temperaure) {
        this.temperaure = temperaure;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (weatherId != null ? weatherId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Weather)) {
            return false;
        }
        Weather other = (Weather) object;
        if ((this.weatherId == null && other.weatherId != null) || (this.weatherId != null && !this.weatherId.equals(other.weatherId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Weather[ weatherId=" + weatherId + " ]";
    }
    
}
