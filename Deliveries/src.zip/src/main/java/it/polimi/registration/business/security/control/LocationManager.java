/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.registration.business.security.control;

import it.polimi.registration.business.security.entity.Event;
import it.polimi.registration.business.security.entity.Location;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Alojzije
 */
@Stateless
public class LocationManager {
    @PersistenceContext
    EntityManager em;
    
    public Location createNewLocation(String address, boolean isOutdoor){
        Location location = new Location();
        location.setAddress(address);
        location.setIsOutdoor(isOutdoor);
        return location;
    }
    
    public void save(Location location){
              em.persist(location);
    }
    
    public Location findById(int id) {
        return em.find(Location.class, id);
    }
     
}
