/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.registration.business.security.entity;

import it.polimi.registration.business.security.control.util.PasswordEncrypter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 *
 * @author miglie
 */
@Entity(name = "USERS")
@NamedQueries({
    @NamedQuery(name = "findAllUsers", query = "SELECT u FROM USERS u"),
    @NamedQuery(name = "findUserById", query = "SELECT u FROM USERS u WHERE u.userId = :userId"),
    @NamedQuery(name = "findUserByEmail", query = "SELECT u FROM USERS u WHERE u.email = :email")
})
public class User implements Serializable {

    private static final long serialVersionUID = 1L;
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "user_id")
    private Integer userId;

    @Id
    @Pattern(regexp = "[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?",
            message = "invalid email")
    @NotNull(message = "May not be empty")
    private String email;
    @NotNull(message = "May not be empty")
    private String password;
    @NotNull(message = "May not be empty")
    private String groupName;

    @NotNull(message = "May not be empty")
    private String name;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "creator", fetch = FetchType.EAGER)
    private Collection<Event> createdEvents;

    @ManyToMany(mappedBy = "invitedUsers")
    private Collection<Event> pendingEvents;

    @ManyToMany(mappedBy = "participatingUsers")
    @JoinTable(name = "user_event_participating",
            joinColumns = @JoinColumn(name = "p_event_id", referencedColumnName = "event_id"),
            inverseJoinColumns = @JoinColumn(name = "p_user_id", referencedColumnName = "user_id"))
    private Collection<Event> participatingEvents;

    @ManyToMany(mappedBy = "associatedUsers")
    private Collection<Notification> notifications;

    public Collection<Notification> getNotifications() {
        return notifications;
    }

    public void setNotifications(Collection<Notification> notifications) {
        this.notifications = notifications;
    }

    public Collection<Event> getParticipatingEvents() {
        if (participatingEvents == null) {
            participatingEvents = new ArrayList<Event>();
        }
        return participatingEvents;
    }

    public void addParticipatingEvent(Event event) {
        if (!getParticipatingEvents().contains(event)) {
            getParticipatingEvents().add(event);
        }
    }

    public void setParticipatingEvents(Collection<Event> participatingEvents) {
        this.participatingEvents = participatingEvents;
    }

    public Collection<Event> getPendingEvents() {
        if (pendingEvents == null) {
            pendingEvents = new ArrayList<>();
        }
        return pendingEvents;
    }

    public void setPendingEvents(Collection<Event> pendingEvents) {
        this.pendingEvents = pendingEvents;
    }

    public void addPendingEvent(Event event) {
        if (!getPendingEvents().contains(event)) {
            getPendingEvents().add(event);
        }
    }

    public void addCreatedEvent(Event event) {
        if (!getCreatedEvents().contains(event)) {
            getCreatedEvents().add(event);
        }
    }

    public Collection<Event> getCreatedEvents() {
        if (createdEvents == null) {
            createdEvents = new ArrayList<>();
        }
        return createdEvents;
    }

    public void setCreatedEvents(Collection<Event> createdEvents) {
        this.createdEvents = createdEvents;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupName() {
        return groupName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = PasswordEncrypter.encryptPassword(password);
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

}
