/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.registration.business.security.control.util;

/**
 *
 * @author Alojzije
 */
public class Message {
    public static int STATUS_OK = 0;
    public static int STATUS_ERR = 1;
    public static int DUPLICATE_NAME = 2;
    public static int DUPLICATE_EMAIL = 3;
    private int code;
    private String Message;

    public Message(int code, String Message) {
        this.code = code;
        this.Message = Message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String Message) {
        this.Message = Message;
    }

}
