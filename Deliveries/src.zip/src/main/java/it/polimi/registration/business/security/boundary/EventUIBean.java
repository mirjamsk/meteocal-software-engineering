/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.registration.business.security.boundary;

import it.polimi.registration.business.security.entity.Event;
import java.awt.event.ActionEvent;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.ViewScoped;
import javax.inject.Named;
import org.primefaces.context.RequestContext;

/**
 *
 * @author Alojzije
 */
@ManagedBean
@ViewScoped
public class EventUIBean {
    private boolean responseRendered = false;
    

    public boolean isResponseRendered() {
                System.out.println("check is set: "+ responseRendered);

        return responseRendered;
    }

    public void setResponseRendered(boolean responseRendered) {
        System.out.println("in set: "+ responseRendered);
        this.responseRendered = responseRendered;
    }
 
}
