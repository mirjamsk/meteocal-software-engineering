/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.registration.business.security.boundary;

import it.polimi.registration.business.security.entity.Event;
import java.awt.event.ActionEvent;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.ViewScoped;
import javax.inject.Named;
import org.primefaces.context.RequestContext;

/**
 *
 * @author Alojzije
 */
@ManagedBean
@ViewScoped
public class EventUIBean {
    private String view = "none";
    private Event selectedEvent;

    public Event getSelectedEvent() {
        return selectedEvent;
    }

    public void setSelectedEvent(Event selectedEvent) {
        this.selectedEvent = selectedEvent;
    }

    
    public String getView() {
        return view;
    }

    public void setView(String view) {
        this.view = view;
    }

    public void save() {  
        //save user  
               System.out.println( "in save");

        RequestContext context = RequestContext.getCurrentInstance();  
        context.addCallbackParam("saved", true);  
        context.addCallbackParam("view", "mama ti ej");  
    
    }
}
