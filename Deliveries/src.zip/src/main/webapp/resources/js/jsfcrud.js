console.log('loaded');

function handleSubmit(args, dialog) {
    var jqDialog = jQuery('#' + dialog);
    if (args.validationFailed) {
        jqDialog.effect('shake', {times: 3}, 100);
    } else {
        PF(dialog).hide();
    }
}


function handleComplete(xhr, status, args) {
    if (args.creationFailed) {
        alert("creationFailed Failed");
    } else {
        $('.createEventContainer').fadeOut();
        $('.updateEventContainer').fadeOut();
        $('.formCreateEvent')[0].reset();
        $('.formUpdateEvent')[0].reset();

        $('.displayEventContainer').fadeIn();

        console.log(args);
    }
}
function showCreateContainer(){
    $('.createEventContainer').fadeIn();    
}
function showDisplayContainer() {
   $('.displayEventContainer').fadeIn();
}

function showUpdateConatiner(){
    $('.updateEventContainer').fadeIn();    
}
function showDisplayEvent() {
    console.log('display event');
    if ($('.createEventContainer').is(':visible')) {
        $('.createEventContainer').fadeOut(showDisplayContainer);
        $('.formCreateEvent')[0].reset();
    } 
    if ($('.updateEventContainer').is(':visible')){
        $('.updateEventContainer').fadeOut(showDisplayContainer);
    } 
}

function showCreateEvent() {
    console.log('display create event');
    console.log();
    if ($('.updateEventContainer').is(':visible')) {
        $('.updateEventContainer').fadeOut(showCreateContainer);
    } 
    if ($('.displayEventContainer').is(':visible')){
        $('.displayEventContainer').fadeOut(showCreateContainer);
    } 
}

function showUpdateEvent() {
    console.log('in show update event');
    
    $('.displayEventContainer').fadeOut(showUpdateConatiner);
    



}

