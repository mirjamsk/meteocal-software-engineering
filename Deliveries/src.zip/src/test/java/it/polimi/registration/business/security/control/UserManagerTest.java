/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.registration.business.security.control;

import it.polimi.registration.business.security.entity.Event;
import it.polimi.registration.business.security.entity.Group;
import it.polimi.registration.business.security.entity.Location;
import it.polimi.registration.business.security.entity.User;
import it.polimi.registration.business.security.entity.Weather;
import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.EntityManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;


public class UserManagerTest {
    
    private UserManager uc;
    private EventManager ec;
    
    @Before
    public void setUp() {
        uc = new UserManager();
        uc.em = mock(EntityManager.class);
        ec = new EventManager();
        ec.em = mock(EntityManager.class);
        
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void newUsersShouldBelongToUserGroupAndSavedOnce() {
//        User newUser = new User();
//        newUser.setName("###");
//        newUser.setEmail("###");
//        uc.save(newUser);       
//        assertThat(newUser.getGroupName(), is(Group.USERS));
//        verify(uc.em,times(1)).persist(newUser);
    }

}
