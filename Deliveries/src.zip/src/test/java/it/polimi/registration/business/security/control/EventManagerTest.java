/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.polimi.registration.business.security.control;

import it.polimi.registration.business.security.entity.Event;
import it.polimi.registration.business.security.entity.Location;
import it.polimi.registration.business.security.entity.User;
import java.util.Arrays;
import javax.persistence.EntityManager;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 *
 * @author Alojzije
 */
public class EventManagerTest {

    private EventManager ec;
    private UserManager uc;
    private LocationManager lc;

    @Before
    public void setUp() {
        ec = new EventManager();
        ec.em = mock(EntityManager.class);
        uc = new UserManager();
        uc.em = mock(EntityManager.class);
        lc = new LocationManager();
        lc.em = mock(EntityManager.class);

    }

    @After
    public void tearDown() {
    }

  

    @Test
    public void invitedUsersShouldHavePendingEvents() {
        Event event = new Event();
        User u1 = new User();
        User u2 = new User();
        ec.inviteUsersToEvent(Arrays.asList(u1, u2), event);
        Assert.assertEquals(2, event.getInvitedUsers().size());
        Assert.assertEquals(1, u1.getPendingEvents().size());

    }

    @Test
    public void participatingUsersShouldHaveEvents() {
        Event event = new Event();
        User u1 = new User();
        User u2 = new User();
        ec.addParticipants(event, Arrays.asList(u1, u2));
        Assert.assertEquals(2, event.getParticipatingUsers().size());
        Assert.assertEquals(1, u1.getParticipatingEvents().size());
    }


}
